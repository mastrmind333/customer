package customer.customer;


public class CustomerConstant {

     public static final String SPACE = " ";

    public static final String BLANK_STRING = "";
}
