package customer.customer;

public enum Gender {
	MALE,FEMALE,OTHER;
	
}
