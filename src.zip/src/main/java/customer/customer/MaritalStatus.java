package customer.customer;

public enum MaritalStatus {
	MARRIED,SINGLE,DIVORSED,WIDOWED;
}
