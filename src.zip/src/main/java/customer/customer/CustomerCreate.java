package customer.customer;

public interface CustomerCreate {
}
