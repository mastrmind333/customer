package customer.customer;

public enum Status {
    ENABLED,
    DISABLED
}
