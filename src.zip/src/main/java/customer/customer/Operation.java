package customer.customer;

public enum Operation {

}
